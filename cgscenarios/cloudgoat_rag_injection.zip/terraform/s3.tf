# -------------------------------------------------------
# KNOWLEDGE BASE BUCKET
# Intentionally misconfigured: any authenticated AWS
# principal can write to this bucket. This is the
# injection vector.
# -------------------------------------------------------
resource "aws_s3_bucket" "knowledge_base" {
  bucket        = "cg-kb-${var.cgid}-${random_id.suffix.hex}"
  force_destroy = true
}

resource "aws_s3_bucket_versioning" "knowledge_base" {
  bucket = aws_s3_bucket.knowledge_base.id
  versioning_configuration {
    status = "Enabled"
  }
}

# Block public access - this is NOT a public bucket misconfiguration.
# The vulnerability is an overly permissive bucket POLICY
# that allows any authenticated AWS principal to PutObject.
resource "aws_s3_bucket_public_access_block" "knowledge_base" {
  bucket                  = aws_s3_bucket.knowledge_base.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# THE VULNERABILITY: any authenticated AWS principal can write objects.
# In a real environment this might be scoped to a specific account
# but still far too broad for a knowledge base bucket.
resource "aws_s3_bucket_policy" "knowledge_base_writeable" {
  bucket = aws_s3_bucket.knowledge_base.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid       = "AllowBedrockRead"
        Effect    = "Allow"
        Principal = {
          Service = "bedrock.amazonaws.com"
        }
        Action = [
          "s3:GetObject",
          "s3:ListBucket"
        ]
        Resource = [
          aws_s3_bucket.knowledge_base.arn,
          "${aws_s3_bucket.knowledge_base.arn}/*"
        ]
      },
      {
        # INTENTIONAL VULNERABILITY: overly broad write access
        # simulates a misconfigured bucket policy where an
        # attacker with any valid AWS credentials can plant documents
        Sid    = "MisconfiguredWriteAccess"
        Effect = "Allow"
        Principal = {
          AWS = aws_iam_role.attacker.arn
        }
        Action = [
          "s3:PutObject",
          "s3:GetObject",
          "s3:ListBucket"
        ]
        Resource = [
          aws_s3_bucket.knowledge_base.arn,
          "${aws_s3_bucket.knowledge_base.arn}/*"
        ]
      }
    ]
  })
}

# Seed the knowledge base with legitimate documents
resource "aws_s3_object" "legit_doc_1" {
  bucket  = aws_s3_bucket.knowledge_base.id
  key     = "docs/employee-handbook.txt"
  content = <<-EOT
    ACME Corp Employee Handbook
    ===========================
    Welcome to ACME Corp. This handbook covers company policies,
    benefits, and procedures. For HR inquiries contact hr@acmecorp.internal.
    
    PTO Policy: Employees accrue 15 days PTO per year.
    Remote Work: Hybrid schedule available with manager approval.
    Benefits: Health, dental, vision coverage available from day 1.
  EOT
}

resource "aws_s3_object" "legit_doc_2" {
  bucket  = aws_s3_bucket.knowledge_base.id
  key     = "docs/it-faq.txt"
  content = <<-EOT
    IT FAQ - ACME Corp
    ==================
    Q: How do I reset my password?
    A: Contact the IT helpdesk at helpdesk@acmecorp.internal or ext 5000.
    
    Q: How do I connect to VPN?
    A: Download the VPN client from the IT portal and use your SSO credentials.
    
    Q: What is the wifi password for the office?
    A: Connect to ACME-Corp-Secure and authenticate with your SSO credentials.
  EOT
}

# -------------------------------------------------------
# SENSITIVE TARGET BUCKET
# This is the prize - contains "confidential" data that
# the attacker wants to access via the pivot.
# The Bedrock agent's IAM role has access to this bucket,
# which it has no legitimate business reason to access.
# -------------------------------------------------------
resource "aws_s3_bucket" "sensitive_data" {
  bucket        = "cg-sensitive-${var.cgid}-${random_id.suffix.hex}"
  force_destroy = true
}

resource "aws_s3_bucket_public_access_block" "sensitive_data" {
  bucket                  = aws_s3_bucket.sensitive_data.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# Plant the flag in the sensitive bucket
resource "aws_s3_object" "flag" {
  bucket  = aws_s3_bucket.sensitive_data.id
  key     = "confidential/customer-data.txt"
  content = <<-EOT
    CONFIDENTIAL - ACME Corp Customer Records
    ==========================================
    This file contains sensitive customer PII and should never
    be accessible via the AI assistant.
    
    FLAG: cg-flag-${random_id.suffix.hex}
    
    Customer ID: 1001 | Name: Alice Johnson | SSN: 123-45-6789
    Customer ID: 1002 | Name: Bob Smith     | SSN: 987-65-4321
  EOT
}
