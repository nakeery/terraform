# -------------------------------------------------------
# ATTACKER IAM USER
# Starting point for the scenario. The attacker has
# obtained these credentials via a phishing attack or
# credential leak. Low privilege - can only write to
# the knowledge base bucket.
# -------------------------------------------------------
resource "aws_iam_user" "attacker" {
  name = "cg-attacker-${var.cgid}"
}

resource "aws_iam_access_key" "attacker" {
  user = aws_iam_user.attacker.name
}

resource "aws_iam_role" "attacker" {
  name = "cg-attacker-role-${var.cgid}"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect    = "Allow"
        Principal = { AWS = aws_iam_user.attacker.arn }
        Action    = "sts:AssumeRole"
      }
    ]
  })
}

# Attacker has very limited permissions - can only
# enumerate and write to the knowledge base bucket.
# This simulates a compromised low-privilege credential.
resource "aws_iam_role_policy" "attacker_policy" {
  name = "cg-attacker-policy-${var.cgid}"
  role = aws_iam_role.attacker.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "ListBuckets"
        Effect = "Allow"
        Action = ["s3:ListAllMyBuckets"]
        Resource = "*"
      },
      {
        Sid    = "KnowledgeBaseBucketAccess"
        Effect = "Allow"
        Action = [
          "s3:PutObject",
          "s3:GetObject",
          "s3:ListBucket"
        ]
        Resource = [
          aws_s3_bucket.knowledge_base.arn,
          "${aws_s3_bucket.knowledge_base.arn}/*"
        ]
      },
      {
        Sid    = "BedrockInvokeAgent"
        Effect = "Allow"
        Action = [
          "bedrock:InvokeAgent"
        ]
        Resource = "*"
      }
    ]
  })
}

# -------------------------------------------------------
# BEDROCK AGENT EXECUTION ROLE
# INTENTIONAL VULNERABILITY: this role is overprivileged.
# It has access to Secrets Manager and the sensitive S3
# bucket, which a legitimate AI assistant has no reason
# to access. This is what makes the pivot possible.
# -------------------------------------------------------
resource "aws_iam_role" "bedrock_agent" {
  name = "cg-bedrock-agent-${var.cgid}"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect    = "Allow"
        Principal = { Service = "bedrock.amazonaws.com" }
        Action    = "sts:AssumeRole"
        Condition = {
          StringEquals = {
            "aws:SourceAccount" = data.aws_caller_identity.current.account_id
          }
        }
      }
    ]
  })
}

resource "aws_iam_role_policy" "bedrock_agent_policy" {
  name = "cg-bedrock-agent-policy-${var.cgid}"
  role = aws_iam_role.bedrock_agent.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "BedrockModelAccess"
        Effect = "Allow"
        Action = [
          "bedrock:InvokeModel",
          "bedrock:InvokeModelWithResponseStream"
        ]
        Resource = "arn:aws:bedrock:${var.region}::foundation-model/*"
      },
      {
        Sid    = "KnowledgeBaseS3Access"
        Effect = "Allow"
        Action = [
          "s3:GetObject",
          "s3:ListBucket"
        ]
        Resource = [
          aws_s3_bucket.knowledge_base.arn,
          "${aws_s3_bucket.knowledge_base.arn}/*"
        ]
      },
      {
        # INTENTIONAL VULNERABILITY: no legitimate AI assistant
        # needs access to a sensitive customer data bucket.
        # Least privilege would scope this to only the KB bucket.
        Sid    = "OverprivilegedS3Access"
        Effect = "Allow"
        Action = [
          "s3:GetObject",
          "s3:ListBucket"
        ]
        Resource = [
          aws_s3_bucket.sensitive_data.arn,
          "${aws_s3_bucket.sensitive_data.arn}/*"
        ]
      },
      {
        # INTENTIONAL VULNERABILITY: no AI assistant needs
        # access to Secrets Manager
        Sid    = "OverprivilegedSecretsAccess"
        Effect = "Allow"
        Action = [
          "secretsmanager:GetSecretValue",
          "secretsmanager:ListSecrets"
        ]
        Resource = "*"
      },
      {
        Sid    = "BedrockKnowledgeBaseAccess"
        Effect = "Allow"
        Action = [
          "bedrock:Retrieve",
          "bedrock:RetrieveAndGenerate"
        ]
        Resource = "*"
      }
    ]
  })
}

data "aws_caller_identity" "current" {}
